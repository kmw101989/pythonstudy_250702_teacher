SELECT title, rental_rate,
CASE
	WHEN rental_rate < 1 THEN "Cheap"
    WHEN rental_rate BETWEEN 1 AND 3 THEN "Moderate"
    ELSE "Expensive"
END AS PriceCategory
FROM film;

# WITH를 사용해서, sakila 데이터베이스의 각 등급별 영화의 평균 길이를 알아보세요.

WITH AvgFilmLength AS (
	SELECT
		rating,
		AVG(length)
	FROM film
	GROUP BY rating
)
SELECT * FROM AvgFilmLength;

# CASE WHEN을 사용해서 customer 테이블의 고객들을 active 컬럼에 따라
# "1 => Active" 또는 "그렇지 않으면 => Inactive"로 분류 및 출력해주세요.

SELECT
	customer_id,
    CASE
		WHEN active = 1 THEN "Active"
        ELSE "Inactive"
    END AS CustomerStatus
FROM customer;


# WITH를 사용해서, sakila의 film 테이블에서 각 rating에 따른
# 평균 rental_duration을 계산해보세요.

WITH AvgRentalDuration AS (
	SELECT
		rating, AVG(rental_duration)
	FROM film
	GROUP BY rating
)
SELECT * FROM AvgRentalDuration;








